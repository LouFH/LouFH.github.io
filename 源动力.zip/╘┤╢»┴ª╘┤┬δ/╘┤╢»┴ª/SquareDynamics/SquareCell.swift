//
//  SquareCell.swift
//  源动力
//
//  Created by 李亚非 on 2017/9/18.
//  Copyright © 2017年 李亚非. All rights reserved.
//

import UIKit

class SquareCell: UITableViewCell {

    @IBOutlet weak var imageTwo: UIImageView!
    // 内容图片的宽高比约束
    internal var aspectConstraint: NSLayoutConstraint? {
        didSet{
            if oldValue != nil {
                imageTwo.removeConstraint(oldValue!)
            }
            if aspectConstraint != nil {
                imageTwo.addConstraint(aspectConstraint!)
            }
        }
    }
    class func MyCell(_ tableView: UITableView) -> SquareCell{
        var cell: SquareCell? = tableView.dequeueReusableCell(withIdentifier: "cell") as? SquareCell
        if cell == nil {
            cell = Bundle.main.loadNibNamed("SquareCell", owner: self, options: nil)?.first as? SquareCell
        }
        return cell!
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func prepareForReuse() {
        super.prepareForReuse()
        //清除内容图片的宽高比约束
        aspectConstraint = nil
    }
    //加载内容图片（并设置高度约束）
    func loadImage(name: String){
        if let image = UIImage(named: name) {
             //计算原始图片的宽高比
            let aspect = image.size.width / image.size.height
            //设置imageView宽高比约束
            aspectConstraint = NSLayoutConstraint(item: imageTwo, attribute: .width, relatedBy: .equal, toItem: imageTwo, attribute: .height, multiplier: aspect, constant: 0.0)
            imageTwo.image = image
        } else {
            //去除imageView里的图片和宽高比约束
            aspectConstraint = nil
            imageTwo.image = nil
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

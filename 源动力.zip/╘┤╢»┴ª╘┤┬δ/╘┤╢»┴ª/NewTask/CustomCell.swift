//
//  CustomCell.swift
//  源动力
//
//  Created by 李亚非 on 2017/9/16.
//  Copyright © 2017年 李亚非. All rights reserved.
//

import UIKit
import JTAppleCalendar
class CustomCell: JTAppleCell{
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var selectedView: UIView!
}

//
//  newTaskViewController.swift
//  源动力
//
//  Created by 李亚非 on 2017/9/16.
//  Copyright © 2017年 李亚非. All rights reserved.
//

import UIKit
import RAMAnimatedTabBarController
import JTAppleCalendar
class newTaskViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var MianTitle = ["起始时间","具体任务","监督模式","提醒录音","隐私设置","悬赏"]
    var imageIcon = ["1","2","3","4","5","16"]
    var subTitle = ["请在日历表中选择两个时间节点","读书两小时","已开启提醒模式","12‘’","公开","账单"]
    let outsideMonthColor = UIColor(colorWitHexValue: 0x584a66)
    let monthColor = UIColor.white
    let selectedMonthColor = UIColor(colorWitHexValue: 0x3a294b)
    let currentDateSelectedViewColor = UIColor(colorWitHexValue: 0x4e3f5d)
    
    var firstDate: Date?
    
    let formatter: DateFormatter = {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = Calendar.current.timeZone
        dateFormatter.locale = Calendar.current.locale
        dateFormatter.dateFormat = "yyyy MM dd"
        return dateFormatter
    }()
    @IBOutlet weak var myTableView: UITableView!
    
    @IBOutlet weak var calendarView: JTAppleCalendarView!
    @IBOutlet weak var month: UILabel!
    let todaysDate = Date()
    override func viewDidLoad() {
        super.viewDidLoad()
        // hidden TabBar
        
        let animatedTabBar = self.tabBarController as! RAMAnimatedTabBarController
        animatedTabBar.animationTabBarHidden(true)
        calendarView.scrollToDate(Date(), animateScroll: false)
        calendarView.selectDates([Date()])
        setupCalendarView()
        
        calendarView.allowsMultipleSelection  = true
        calendarView.isRangeSelectionUsed = true
        
        myTableView.delegate = self
        myTableView.dataSource = self
    }
    func setupCalendarView(){
        // Setup calendar spacing
        calendarView.minimumLineSpacing = 0
        calendarView.minimumInteritemSpacing = 0
        // Setup labels
        calendarView.visibleDates { (visibleDates) in
            self.setupViewsOfCalendar(from: visibleDates)
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        // Show TabBar
        let animatedTabBar = self.tabBarController as! RAMAnimatedTabBarController
        animatedTabBar.animationTabBarHidden(false)
    }
    /// JTAppleCell
    func handleCellTextColor(view: JTAppleCell?, cellState: CellState){
        formatter.dateFormat = "yyyy MM dd"
        let todaysDateString = formatter.string(from: todaysDate)
        let monthDateString = formatter.string(from: cellState.date)
        guard let validCell = view as? CustomCell else { return }
        if todaysDateString == monthDateString {
            validCell.dateLabel.textColor = UIColor.blue
        } else {
            if cellState.isSelected {
                validCell.dateLabel.textColor = selectedMonthColor
            } else {
                if cellState.dateBelongsTo == .thisMonth{
                    validCell.dateLabel.textColor = monthColor
                } else {
                    validCell.dateLabel.textColor = outsideMonthColor
                }
            }
        }
    }
    func handleCellSelected(view: JTAppleCell?, cellState: CellState){
        guard let validCell = view as? CustomCell else { return }
        if cellState.isSelected {
            validCell.selectedView.isHidden = false
        } else {
            validCell.selectedView.isHidden = true
        }
    }
    func setupViewsOfCalendar(from visibleDates: DateSegmentInfo) {
        let date = visibleDates.monthDates.first!.date
        self.formatter.dateFormat = "MMMM"
        self.month.text = self.formatter.string(from: date)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    /// tableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = MyCell()
        cell = MyCell.MyCell(tableView)
        cell.imageicon.image = UIImage(named: imageIcon[indexPath.row])
        cell.mainTitle.text = MianTitle[indexPath.row]
        cell.subTitle.text = subTitle[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = MyCell.MyCell(tableView)
        if MianTitle[indexPath.row] == "隐私设置" {
            if subTitle[indexPath.row] == "公开"{
                subTitle[indexPath.row] = "仅自己可见"
                cell.subTitle.text = subTitle[indexPath.row]
            }else{
                subTitle[indexPath.row] = "公开"
                cell.subTitle.text = subTitle[indexPath.row]
            }            
        }
        tableView.reloadData()
       
    }

    
}

extension newTaskViewController: JTAppleCalendarViewDataSource{
    func configureCalendar(_ calendar: JTAppleCalendarView) -> ConfigurationParameters {
        formatter.dateFormat = "yyyy MM dd"
        formatter.timeZone = Calendar.current.timeZone
        formatter.locale = Calendar.current.locale
        
        let startDate = formatter.date(from: "2017 01 01")!
        let endDate = formatter.date(from: "2017 12 31")!
        let parameters = ConfigurationParameters(startDate: startDate, endDate: endDate)
        return parameters
    }
}


extension newTaskViewController: JTAppleCalendarViewDelegate {
    // Display the cell
    func calendar(_ calendar: JTAppleCalendarView, cellForItemAt date: Date, cellState: CellState, indexPath: IndexPath) -> JTAppleCell {
        let cell = calendar.dequeueReusableJTAppleCell(withReuseIdentifier: "CustomCell", for: indexPath) as! CustomCell
        cell.dateLabel.text = cellState.text
        handleCellSelected(view: cell, cellState: cellState)
        handleCellTextColor(view: cell, cellState: cellState)
        return cell
    }
    
    func calendar(_ calendar: JTAppleCalendarView, didSelectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        if firstDate != nil {
            calendarView.selectDates(from: firstDate!, to: date,  triggerSelectionDelegate: false, keepSelectionIfMultiSelectionAllowed: true)
        } else {
            firstDate = date
        }
        handleCellSelected(view: cell, cellState: cellState)
        handleCellTextColor(view: cell, cellState: cellState)
        handleSelection(cell: cell, cellState: cellState)
    }
    func handleSelection(cell: JTAppleCell?, cellState: CellState){
        let myCustomCell = cell as! CustomCell
        switch cellState.selectedPosition() {
        case .full, .left, .right:
            myCustomCell.selectedView.isHidden = false
            myCustomCell.selectedView.backgroundColor = UIColor.yellow
        case .middle:
            myCustomCell.selectedView.isHidden = false
            myCustomCell.selectedView.backgroundColor = UIColor.blue
        default:
            myCustomCell.selectedView.isHidden = true
            myCustomCell.selectedView.backgroundColor = nil
        }
    }
    func calendar(_ calendar: JTAppleCalendarView, didDeselectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        handleCellSelected(view: cell, cellState: cellState)
        handleCellTextColor(view: cell, cellState: cellState)
        handleSelection(cell: cell, cellState: cellState)
    }
    func calendar(_ calendar: JTAppleCalendarView, willDisplayCell cell: JTAppleCell, date: Date, cellState: CellState) {
        handleSelection(cell: cell, cellState: cellState)
    }
    func calendar(_ calendar: JTAppleCalendarView, didScrollToDateSegmentWith visibleDates: DateSegmentInfo) {
       setupViewsOfCalendar(from: visibleDates)
    }
}
extension UIColor{
    convenience init(colorWitHexValue value: Int, alpha: CGFloat = 1.0){
        self.init(
            red: CGFloat((value & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((value & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(value & 0x0000FF) / 255.0,
            alpha: alpha
        )
    }
}

//
//  MyCell.swift
//  源动力
//
//  Created by 李亚非 on 2017/9/17.
//  Copyright © 2017年 李亚非. All rights reserved.
//

import UIKit

class MyCell: UITableViewCell {

    @IBOutlet weak var imageicon: UIImageView!
    @IBOutlet weak var mainTitle: UILabel!
    @IBOutlet weak var subTitle: UILabel!
    class func MyCell(_ tableView: UITableView) -> MyCell{
        var cell: MyCell? = tableView.dequeueReusableCell(withIdentifier: "cell") as? MyCell
        if cell == nil {
            cell = Bundle.main.loadNibNamed("MyCell", owner: self, options: nil)?.first as? MyCell
        }
        return cell!
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
}

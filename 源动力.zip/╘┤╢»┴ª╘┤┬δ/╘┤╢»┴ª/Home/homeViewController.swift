//
//  homeViewController.swift
//  源动力
//
//  Created by 李亚非 on 2017/9/14.
//  Copyright © 2017年 李亚非. All rights reserved.
//

import UIKit
import UICircularProgressRing
class homeViewController: UIViewController, UICircularProgressRingDelegate {

    
    @IBAction func dask(_ sender: UIButton) {
        amintedemo()
    }
    
    @IBOutlet weak var ring: UICircularProgressRingView!
    fileprivate var waterView: LYFWaveView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // return button no word,white icon
        let item = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        self.navigationItem.backBarButtonItem = item
        self.navigationItem.backBarButtonItem?.tintColor = UIColor.white
        // Do any additional setup after loading the view.
        // round progress bar
        ring.animationStyle = kCAMediaTimingFunctionLinear
        ring.backgroundColor = UIColor.white
        ring.layer.cornerRadius = 100
        ring.layer.masksToBounds = true
        ring.delegate = self
        // waterView set
        let frame = CGRect(x: 0, y: 64, width: self.view.bounds.width, height: 270)
        waterView = LYFWaveView(frame: frame, color: UIColor.white)
        waterView!.backgroundColor = UIColor(red: 54/255, green: 116/255, blue: 154/255, alpha: 1)
        waterView?.realWaveColor = UIColor(red: 217/255, green: 88/255, blue: 120/255, alpha: 1)
        waterView?.maskWaveColor = UIColor(red: 255/255, green: 213/255, blue: 147/255, alpha: 1)
        // Add WaveView
        self.view.addSubview(waterView!)
        self.view.addSubview(ring)
        // Start wave
        waterView!.start()
        //self.hidesBottomBarWhenPushed = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func finishedUpdatingProgress(forRing ring: UICircularProgressRingView) {
        if ring === ring {
            print("From delegate: Ring  finished")
        }
    }
    
    func amintedemo(){
        ring.animationStyle = kCAMediaTimingFunctionLinear
        ring.setProgress(value: 89, animationDuration: 12, completion: nil)
    }
}

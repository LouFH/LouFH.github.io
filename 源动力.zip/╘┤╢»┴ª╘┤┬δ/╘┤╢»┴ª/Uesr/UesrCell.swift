//
//  UesrCell.swift
//  源动力
//
//  Created by 李亚非 on 2017/9/17.
//  Copyright © 2017年 李亚非. All rights reserved.
//

import UIKit

class UesrCell: UITableViewCell {

    @IBOutlet weak var imageOne: UIImageView!
    @IBOutlet weak var LabelOne: UILabel!
    class func MyCell(_ tableView: UITableView) -> UesrCell{
        var cell: UesrCell? = tableView.dequeueReusableCell(withIdentifier: "cell") as? UesrCell
        if cell == nil {
            cell = Bundle.main.loadNibNamed("UesrCell", owner: self, options: nil)?.first as? UesrCell
        }
        return cell!
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

//
//  UesrViewController.swift
//  源动力
//
//  Created by 李亚非 on 2017/9/17.
//  Copyright © 2017年 李亚非. All rights reserved.
//

import UIKit

/// 头部视图的高度
private let headerviewH: CGFloat = 150

/// 屏幕的宽度
private let screenW: CGFloat = UIScreen.main.bounds.width

/// 导航栏的高度
private let navigationH: CGFloat = 44

/// 状态栏的高度
private let statusH: CGFloat = 20


/// 颜色
private let darkGreen = UIColor(red: 55/255, green: 117/255, blue: 153/255, alpha: 1.0)


class UesrViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UesrCell()
        cell = UesrCell.MyCell(tableView)
        cell.imageOne.image = UIImage(named: imageOneName[indexPath.row])
        cell.LabelOne.text = titleOne[indexPath.row]
     
        return cell
    }
    let imageOneName = ["8","9","11","12","13","14","15"]
    let titleOne = ["登榜记录","相册","收藏","我赞过的","设置","成长的小蜗","我的悬赏"]

    
    @IBOutlet weak var userTableView: UITableView!
    /// 头部视图
    var Headerview: UIView!
    
    /// 头部视图图片
    var HeaderImage: UIImageView!
    
    /// 分割线
    var lineView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configTableView()
        configHeaderView()
        // Do any additional setup after loading the view.
    }
    /// 配置TableView
    private func configTableView() {
        // 设置表格顶部间距, 使得HaderView不被遮挡
        userTableView.contentInset = UIEdgeInsets(top: headerviewH, left: 0, bottom: 0, right: 0)
        // 设置指示器的间距, 等于表格顶部的间距
        userTableView.scrollIndicatorInsets = userTableView.contentInset
        userTableView.dataSource = self
        userTableView.delegate = self
    }
    /// 配置HaderView
    private func configHeaderView() {
        
        Headerview = UIView(frame: CGRect(x: 0.0, y: 64.0, width: screenW, height: headerviewH))
        
        Headerview.backgroundColor = darkGreen
        
        HeaderImage = UIImageView(frame: Headerview.bounds)
        
        // 设置图像
        HeaderImage.image = UIImage(named: "10")
        
        // 设置图像显示比例
        HeaderImage.contentMode = .scaleToFill
        
        // 设置图像裁切
        HeaderImage.clipsToBounds = true
        //MARK: 添加分割线: 1个像素点
        // 1个像素点 / 分辨率
        let lineH = 1 / UIScreen.main.scale
        lineView = UIView(frame: CGRect(x: 0, y: headerviewH - lineH, width: screenW, height: lineH))
        lineView.backgroundColor = UIColor.lightGray
        // 添加控件
        Headerview.addSubview(lineView)
        Headerview.addSubview(HeaderImage)
        view.addSubview(Headerview)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

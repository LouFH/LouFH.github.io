//
//  DemoCell.swift
//  源动力
//
//  Created by 李亚非 on 2017/9/19.
//  Copyright © 2017年 李亚非. All rights reserved.
//

import UIKit
import FoldingCell
class DemoCell: FoldingCell {

//    @IBOutlet weak var avatarImgCell: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func animationDuration(_ itemIndex:NSInteger, type:AnimationType)-> TimeInterval {
        
        let durations = [0.26, 0.2, 0.2]
        return durations[itemIndex]
    }
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }

}

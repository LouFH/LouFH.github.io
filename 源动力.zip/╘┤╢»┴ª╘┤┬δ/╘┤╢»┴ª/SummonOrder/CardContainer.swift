//
//  CardContainer.swift
//  源动力
//
//  Created by 李亚非 on 2017/9/18.
//  Copyright © 2017年 李亚非. All rights reserved.
//

import UIKit
// Protocol for handeling card swipeing
protocol CardContainerDataSource {
    /// This method should be called if a card 🃏 is swiped to the left
    func cardSwipedLeft(_ card: Card)
    ///This method should be called if a card 🃏 is swiped to the right
    func cardSwipedRight(_ card: Card)
}

class CardContainer: UIView, CardContainerDataSource {

    fileprivate let MAX_BUFFER_SIZE = 2
    fileprivate let CARD_HEIGHT: CGFloat = 400
    fileprivate let CARD_WIDTH: CGFloat = 290
    
    fileprivate var cardsLoadedIndex = 0
    fileprivate var cards = [Card]()
    
    fileprivate var checkButton = UIButton(frame: CGRect(x: 135, y: 475, width: 100, height: 35))
    
    fileprivate var exampleCardLabels: [String]
    
    fileprivate var isLoaded = false
    
    override init(frame: CGRect) {
        exampleCardLabels = ["召集令-1", "召集令-2", "召集令-3", "召集令-4", "召集令-5","召集令-6","召集令-7","召集令-8","召集令-1", "召集令-2", "召集令-3", "召集令-4", "召集令-5","召集令-6","召集令-7","召集令-8","召集令-1", "召集令-2", "召集令-3", "召集令-4", "召集令-5","召集令-6","召集令-7","召集令-8"]
        super.init(frame: frame)
        self.setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        exampleCardLabels = ["召集令-1", "召集令-2", "召集令-3", "召集令-4", "召集令-5","召集令-6","召集令-7","召集令-8","召集令-1", "召集令-2", "召集令-3", "召集令-4", "召集令-5","召集令-6","召集令-7","召集令-8","召集令-1", "召集令-2", "召集令-3", "召集令-4", "召集令-5","召集令-6","召集令-7","召集令-8"]
        super.init(coder: aDecoder)
        self.setupViews()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        if(!isLoaded) {
            self.loadCards()
        }
    }
    
    fileprivate func setupViews() {
       
        checkButton.setTitle("立即报名", for: .normal)
        checkButton.setTitleColor(UIColor.black, for: .normal)
        checkButton.layer.cornerRadius = 10
        checkButton.layer.borderWidth = 1
       // self.addSubview(checkButton)
    }
    
    
    fileprivate func createCard(_ label: String) -> Card {
        let card = Card(frame: CGRect(x: (self.frame.width - CARD_WIDTH)/2, y: (self.frame.height - CARD_HEIGHT)/2, width: CARD_WIDTH, height: CARD_HEIGHT))
        card.backgroundColor = UIColor(red: 55/255, green: 117/255, blue: 153/255, alpha: 1.0)
        card.text = label
        card.delegate = self
        return card
    }
    
    fileprivate func loadCards() {
        for label in exampleCardLabels {
            cards.append(createCard(label))
        }
        for i in 0 ..< cards.count {
            if(i == 0) {
                self.addSubview(cards[i])
            } else {
                self.insertSubview(cards[i], belowSubview: cards[i-1])
            }
        }
        self.isLoaded = true
    }
    
    // MARK: - CardContainerDataSource
    
    func cardSwipedLeft(_ card: Card) {
        let finishPoint = CGPoint(x: -500, y: 2.0 * card.yFromCenter + card.originalPoint.y)
        self.animateCardToPoint(card, finishPoint: finishPoint) { complete in
            card.removeFromSuperview()
            self.cards.removeFirst()
        }
        print("LEFT")
    }
    
    func cardSwipedRight(_ card: Card) {
        let finishPoint = CGPoint(x: 500, y: 2.0 * card.yFromCenter + card.originalPoint.y);
        self.animateCardToPoint(card, finishPoint: finishPoint) { complete in
            card.removeFromSuperview()
            self.cards.removeFirst()
        }
        print("RIGHT")
    }
    
    /**
     Animates a card do a specific location in the container
     */
    fileprivate func animateCardToPoint(_ card: Card, finishPoint: CGPoint, compleation: @escaping (Bool) -> Void) {
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            card.center = finishPoint
        }, completion: { (complete) -> Void in
            compleation(complete)
        })
    }
}
